package com.cg.Service;

import com.cg.Dto.CartDto;

public interface AddBookToCartService {
	
	Object addBookToCart(CartDto cart);

	void deleteAll();

}
